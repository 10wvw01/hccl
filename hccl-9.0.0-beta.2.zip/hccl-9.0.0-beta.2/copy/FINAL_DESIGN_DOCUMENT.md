# HCCL LocalCopy/LocalReduce 公共函数抽取与优化方案设计文档

**版本**：v2.0  
**日期**：2026-06-21  
**作者**：重构团队  
**状态**：已实施

---

## 目录

1. [需求分析](#1-需求分析)
2. [架构设计](#2-架构设计)
3. [API 设计](#3-api-设计)
4. [实现方案](#4-实现方案)
5. [向后兼容性](#5-向后兼容性)
6. [测试策略](#6-测试策略)
7. [部署计划](#7-部署计划)
8. [附录：变更对比](#8-附录变更对比)

---

## 1. 需求分析

### 1.1 问题背景

通过对 `src/ops/<op>/template/aicpu/` 目录下所有算子模板的分析，发现以下问题：

| 问题类别 | 具体表现 | 影响范围 |
|---------|---------|---------|
| **代码重复** | `LocalCopy` / `LocalReduce` 的调用模式高度重复（5 大模式） | 19+ 个模板文件 |
| **同步逻辑分散** | `PreSyncInterThreads` / `PostSyncInterThreads` 的调用模式在每个模板中重复 | 16+ 处 |
| **Barrier 逻辑分散** | 64 位/PROD 场景的 `BatchModeEnd/Start/ThreadJoin` 序列重复 | 6+ 处 |
| **命名不精确** | `PreCopyToScratch` / `PostCopyFromScratch` 中的 "Scratch" 限定词不准确 | 影响可读性 |
| **接口冗余** | 多个独立函数完成同一流程（copy → sync → barrier） | 影响可维护性 |

### 1.2 需求目标

| 目标 | 描述 |
|------|------|
| **代码复用** | 将重复模式抽取为公共函数，消除代码重复 |
| **接口简化** | 通过函数重载合并相关操作，减少调用复杂度 |
| **命名优化** | 移除不准确的限定词，使命名更具通用性 |
| **向后兼容** | 保留原有 API，不破坏现有调用方 |
| **可维护性** | 集中维护公共逻辑，降低 bug 修复成本 |

### 1.3 三项优化任务

| 任务 | 描述 | 优先级 |
|------|------|--------|
| **Task 1** | 合并 `PreSyncIfMultiThread` / `PostSyncIfMultiThread` 到 `PreCopy` / `PostCopy` 流程 | 高 |
| **Task 2** | 重命名 `PreCopyToScratch` / `PostCopyFromScratch`，移除 "Scratch" 限定 | 高 |
| **Task 3** | 合并 `AicpuReduceBarrier` 到 `LocalDmaReduceCopy` 流程 | 高 |

---

## 2. 架构设计

### 2.1 整体架构

```
┌─────────────────────────────────────────────────────────────────────┐
│                    Template Layer (aicpu/*.cc)                      │
│  ┌───────────────────────────────────────────────────────────────┐  │
│  │ ins_temp_all_reduce_mesh_1D_two_shot.cc                      │  │
│  │ ins_temp_all_gather_mesh_1D.cc                              │  │
│  │ ins_temp_reduce_scatter_mesh_1D.cc                          │  │
│  │ reduce_mesh_1D.cc                                           │  │
│  │ ins_temp_broadcast_mesh_1D_two_shot.cc                      │  │
│  └───────────────────────────────────────────────────────────────┘  │
│                              │                                      │
│                              ▼                                      │
│  ┌───────────────────────────────────────────────────────────────┐  │
│  │              alg_data_trans_wrapper.h/.cc (v2)               │  │
│  │  ┌───────────────────────────────────────────────────────┐   │  │
│  │  │ 原有 API（保留，向后兼容）                             │   │  │
│  │  │   LocalCopy / LocalReduce / LocalCopySlices          │   │  │
│  │  │   PreSyncInterThreads / PostSyncInterThreads         │   │  │
│  │  │   AicpuReduce / AicpuReduceBarrier                  │   │  │
│  │  └───────────────────────────────────────────────────────┘   │  │
│  │  ┌───────────────────────────────────────────────────────┐   │  │
│  │  │ 新增高层 API（v2 优化）                               │   │  │
│  │  │   PreCopyToBuffer / PostCopyToOutput                │   │  │
│  │  │   PreCopyToBuffer(+sync) / PostCopyToOutput(+sync) │   │  │
│  │  │   LocalDmaReduceCopy / LocalDmaReduceCopy(+barrier)│   │  │
│  │  │   PostLocalReduceAllRanks                          │   │  │
│  │  │   LocalScatterSelfCopy / LocalGatherSelfCopy       │   │  │
│  │  └───────────────────────────────────────────────────────┘   │  │
│  └───────────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────────┐
│                        Hcomm Layer                                  │
│  HcommLocalCopyOnThread / HcommLocalReduceOnThread / HcommThreadJoin│
└─────────────────────────────────────────────────────────────────────┘
```

### 2.2 模块职责

| 模块 | 职责 |
|------|------|
| **Template Layer** | 算子算法实现，调用 wrapper 层的高层 API |
| **Wrapper Layer** | 提供组合式高层 API，封装重复模式 |
| **Hcomm Layer** | 底层通信原语（`HcommLocalCopyOnThread` 等） |

### 2.3 设计原则

1. **零侵入**：保留所有原有 API，通过重载扩展新功能
2. **行为等价**：新函数行为与原内联代码完全一致
3. **单一职责**：每个函数只做一件事，通过重载组合
4. **可扩展性**：命名通用，便于后续扩展到其他场景

---

## 3. API 设计

### 3.1 新增 API 列表

| API | 签名要点 | 功能描述 |
|-----|---------|---------|
| `PreCopyToBuffer` | `(thread, buffInfo, myAlgRank, sliceSize, sliceCount)` | 数据从 input 拷贝到中间 buffer |
| `PreCopyToBuffer`（+sync） | `(..., mainThread, subThreads, notifyIdx)` | 先 PreSync 再拷贝 |
| `PostCopyToOutput` | `(thread, buffInfo, myAlgRank, rankSize, sliceSize, sliceCount, skipSelf=true)` | 数据从中间 buffer 拷贝到 output |
| `PostCopyToOutput`（+sync） | `(..., mainThread, subThreads, notifyIdx)` | 先拷贝再 PostSync |
| `LocalDmaReduceCopy` | `(thread, buffInfo, processSize, count)` | DMA 消减拷贝（向后兼容） |
| `LocalDmaReduceCopy`（+barrier） | `(..., algTag, allThreads, needBarrier, timeout=0)` | DMA 拷贝 + 可选 barrier |
| `PostLocalReduceAllRanks` | `(thread, buffInfo, myAlgRank, rankSize, sliceSize, sliceCount, dataType, reduceOp)` | 跨 rank 分片归约到 output |
| `LocalScatterSelfCopy` | `(thread, buffInfo, myAlgRank, remoteIdx, ...offsets/sizes)` | Scatter 阶段自拷贝 |
| `LocalGatherSelfCopy` | `(thread, buffInfo, myAlgRank, remoteIdx, offset, size, count)` | Gather 阶段自拷贝 |

### 3.2 API 详细设计

#### 3.2.1 PreCopyToBuffer（重命名 + 重载）

```cpp
// 基础版本：仅数据拷贝
HcclResult PreCopyToBuffer(
    const ThreadHandle &thread,           // 执行拷贝的线程
    const BuffInfo &buffInfo,             // buffer 信息（inputPtr, hcclBuff, offsets）
    u32 myAlgRank,                        // 当前 rank 的算法序号
    u64 sliceSize,                        // 每片数据大小
    u64 sliceCount                        // 每片数据元素个数
);

// 带 sync 重载：先 PreSync 再拷贝
HcclResult PreCopyToBuffer(
    const ThreadHandle &thread,           // 执行拷贝的线程
    const BuffInfo &buffInfo,             // buffer 信息
    u32 myAlgRank,                        // 当前 rank 的算法序号
    u64 sliceSize,                        // 每片数据大小
    u64 sliceCount,                       // 每片数据元素个数
    // === sync 参数 ===
    const ThreadHandle &mainThread,       // 主线程（用于 record）
    const std::vector<ThreadHandle> &subThreads,  // 从线程（用于 wait）
    const std::vector<u32> &notifyIdxMainToSub   // notify 索引
);
```

**执行流程**：
```
PreCopyToBuffer(+sync):
    └── PreSyncIfMultiThread(mainThread, subThreads, notifyIdx)
        └── PreCopyToBuffer(基础版本)
```

#### 3.2.2 PostCopyToOutput（重命名 + 重载）

```cpp
// 基础版本：仅数据拷贝
HcclResult PostCopyToOutput(
    const ThreadHandle &thread,           // 执行拷贝的线程
    const BuffInfo &buffInfo,             // buffer 信息
    u32 myAlgRank,                        // 当前 rank 的算法序号
    u32 rankSize,                         // 总 rank 数
    u64 sliceSize,                        // 每片数据大小
    u64 sliceCount,                       // 每片数据元素个数
    bool skipSelf = true                  // 是否跳过自身分片（默认跳过）
);

// 带 sync 重载：先拷贝再 PostSync
HcclResult PostCopyToOutput(
    const ThreadHandle &thread,           // 执行拷贝的线程
    const BuffInfo &buffInfo,             // buffer 信息
    u32 myAlgRank,                        // 当前 rank 的算法序号
    u32 rankSize,                         // 总 rank 数
    u64 sliceSize,                        // 每片数据大小
    u64 sliceCount,                       // 每片数据元素个数
    bool skipSelf,                        // 是否跳过自身分片
    // === sync 参数 ===
    const ThreadHandle &mainThread,       // 主线程（用于 wait）
    const std::vector<ThreadHandle> &subThreads,  // 从线程（用于 record）
    const std::vector<u32> &notifyIdxSubToMain   // notify 索引
);
```

**执行流程**：
```
PostCopyToOutput(+sync):
    └── PostCopyToOutput(基础版本)
        └── PostSyncIfMultiThread(mainThread, subThreads, notifyIdx)
```

#### 3.2.3 LocalDmaReduceCopy（新增 barrier 重载）

```cpp
// 基础版本：仅 DMA 拷贝（向后兼容）
HcclResult LocalDmaReduceCopy(
    const ThreadHandle &thread,           // 执行拷贝的线程
    const BuffInfo &buffInfo,             // buffer 信息
    u64 processSize,                      // 总数据大小
    u64 count                            // 数据元素个数
);

// 带 barrier 重载：DMA 拷贝 + 可选 barrier
HcclResult LocalDmaReduceCopy(
    const ThreadHandle &thread,           // 执行拷贝的线程
    const BuffInfo &buffInfo,             // buffer 信息
    u64 processSize,                      // 总数据大小
    u64 count,                            // 数据元素个数
    // === barrier 参数 ===
    const std::string &algTag,            // 算法标签（用于 HcommBatchMode）
    const std::vector<ThreadHandle> &allThreads,  // 所有线程（用于 ThreadJoin）
    bool needBarrier,                     // 是否需要 barrier
    u32 barrierTimeout = 0                // barrier 超时时间（0=默认）
);
```

**执行流程**：
```
LocalDmaReduceCopy(+barrier):
    └── LocalDmaReduceCopy(基础版本)
        └── if (needBarrier): AicpuReduceBarrier(algTag, allThreads, timeout)
```

### 3.3 命名规范

| 命名规则 | 示例 |
|---------|------|
| **动词+目标** | `PreCopyToBuffer`（拷贝到 buffer）、`PostCopyToOutput`（拷贝到 output） |
| **动作+上下文** | `LocalScatterSelfCopy`（Scatter 阶段的自拷贝）、`LocalGatherSelfCopy`（Gather 阶段的自拷贝） |
| **行为+范围** | `PostLocalReduceAllRanks`（归约所有 rank 的分片） |

---

## 4. 实现方案

### 4.1 文件结构

```
src/ops/op_common/template/wrapper/
├── alg_data_trans_wrapper.h    # API 声明（新增 v2 接口）
└── alg_data_trans_wrapper.cc   # API 实现（新增 v2 实现）
```

### 4.2 实现要点

#### 4.2.1 重命名策略

将 `PreCopyToScratch` / `PostCopyFromScratch` 重命名为 `PreCopyToBuffer` / `PostCopyToOutput`：

```cpp
// 原实现（PreCopyToScratch）
DataSlice srcSlice(buffInfo.inputPtr, buffInfo.inBuffBaseOff, sliceSize, sliceCount);
DataSlice dstSlice(buffInfo.hcclBuff.addr, buffInfo.hcclBuffBaseOff + myAlgRank * sliceSize, ...);
LocalCopy(thread, srcSlice, dstSlice);

// 新实现（PreCopyToBuffer）—— 逻辑完全相同，仅函数名变更
DataSlice srcSlice(buffInfo.inputPtr, buffInfo.inBuffBaseOff, sliceSize, sliceCount);
DataSlice dstSlice(buffInfo.hcclBuff.addr, buffInfo.hcclBuffBaseOff + myAlgRank * sliceSize, ...);
LocalCopy(thread, srcSlice, dstSlice);
```

#### 4.2.2 Sync 合并实现

```cpp
HcclResult PreCopyToBuffer(const ThreadHandle &thread, const BuffInfo &buffInfo, u32 myAlgRank,
    u64 sliceSize, u64 sliceCount,
    const ThreadHandle &mainThread,
    const std::vector<ThreadHandle> &subThreads,
    const std::vector<u32> &notifyIdxMainToSub)
{
    // Step 1: 多线程同步（subThreads 为空时自动跳过）
    CHK_RET(PreSyncIfMultiThread(mainThread, subThreads, notifyIdxMainToSub));
    // Step 2: 数据拷贝
    return PreCopyToBuffer(thread, buffInfo, myAlgRank, sliceSize, sliceCount);
}
```

#### 4.2.3 Barrier 合并实现

```cpp
HcclResult LocalDmaReduceCopy(const ThreadHandle &thread, const BuffInfo &buffInfo, u64 processSize,
    u64 count, const std::string &algTag, const std::vector<ThreadHandle> &allThreads,
    bool needBarrier, u32 barrierTimeout)
{
    // Step 1: DMA 拷贝
    CHK_RET(LocalDmaReduceCopy(thread, buffInfo, processSize, count));
    // Step 2: 可选 barrier
    if (needBarrier) {
        CHK_RET(AicpuReduceBarrier(algTag, allThreads, barrierTimeout));
    }
    return HCCL_SUCCESS;
}
```

### 4.3 调用方适配

#### 4.3.1 使用新带 sync 版本

**适用场景**：sync 与 copy 直接相邻

```cpp
// 原代码（4 行）
if (threads.size() > 1) {
    std::vector<ThreadHandle> subThreads(threads.begin() + 1, threads.end());
    CHK_RET(PreSyncInterThreads(threads[0], subThreads, notifyIdxMainToSub_));
}
CHK_RET(PreCopyToBuffer(threads[0], buffInfo, myAlgRank, sliceSize, sliceCount));

// 新代码（1 行）
CHK_RET(PreCopyToBuffer(threads[0], buffInfo, myAlgRank, sliceSize, sliceCount,
                        threads[0], subThreads, notifyIdxMainToSub_));
```

#### 4.3.2 使用独立版本

**适用场景**：sync 与 copy 不相邻（中间有其他操作）

```cpp
// 示例：reduce_mesh_1D.cc 中 barrier 在 PostSync 之后
CHK_RET(PostSyncIfMultiThread(masterThread, subThreads, notifyIdxSubToMain_));
if (needAicpuReduce_) {
    CHK_RET(AicpuReduceBarrier(param.algTag, threads));  // 使用独立版本
}
```

---

## 5. 向后兼容性

### 5.1 兼容性保障

| 措施 | 说明 |
|------|------|
| **保留原 API** | `LocalCopy` / `LocalReduce` / `PreSyncInterThreads` / `PostSyncInterThreads` / `AicpuReduceBarrier` 全部保留 |
| **函数重载** | 新增功能通过重载实现，不修改原有函数签名 |
| **重命名处理** | 通过编译期检查确保所有调用方更新 |
| **渐进式迁移** | 调用方可逐步迁移到新 API，无需一次性修改 |

### 5.2 迁移路径

| 阶段 | 工作 | 影响范围 |
|------|------|---------|
| **Phase 1** | 新增 v2 API，保留所有原 API | 零影响 |
| **Phase 2** | 更新调用方使用新重命名 API（PreCopyToBuffer/PostCopyToOutput） | 需修改 5+ 模板 |
| **Phase 3** | 逐步迁移到带 sync/barrier 的重载版本 | 可选，按需迁移 |
| **Phase 4** | 移除独立 sync/barrier 调用（可选） | 需评估影响范围 |

---

## 6. 测试策略

### 6.1 测试覆盖

| 测试类型 | 测试内容 |
|---------|---------|
| **单元测试** | 每个新 API 的独立功能测试（边界条件、错误处理） |
| **集成测试** | 完整算子流程测试（all_reduce、all_gather、reduce_scatter、broadcast、reduce） |
| **回归测试** | 确保原有功能不受影响 |
| **性能测试** | 验证无性能回退（吞吐量、延迟） |

### 6.2 测试用例

| 用例 | 描述 |
|------|------|
| **空数据** | `sliceSize=0` 时直接返回 SUCCESS |
| **单线程** | `subThreads.empty()` 时 sync 自动跳过 |
| **多线程** | 验证 sync 正确执行 |
| **64 位数据** | 验证 barrier 正确执行 |
| **PROD reduce** | 验证 barrier 正确执行 |
| **nullptr 检查** | 验证错误处理 |

---

## 7. 部署计划

### 7.1 实施步骤

| 步骤 | 任务 | 责任人 | 时间 |
|------|------|--------|------|
| 1 | 更新 `alg_data_trans_wrapper.h`（新增声明） | 架构师 | 1 天 |
| 2 | 更新 `alg_data_trans_wrapper.cc`（新增实现） | 开发 | 1 天 |
| 3 | 更新调用方模板文件（重命名适配） | 开发 | 2 天 |
| 4 | 编写单元测试 | 测试 | 2 天 |
| 5 | 执行回归测试 | 测试 | 3 天 |
| 6 | 性能测试验证 | 测试 | 2 天 |
| 7 | 代码审查 | 架构师 | 1 天 |
| 8 | 部署上线 | 运维 | 1 天 |

### 7.2 风险评估

| 风险 | 等级 | 缓解措施 |
|------|------|---------|
| 重命名遗漏 | 低 | C++ 编译器会在编译期捕获 |
| 重载歧义 | 低 | 参数数量不同，无歧义 |
| 性能回退 | 无 | 新函数是原函数的组合，可完全内联 |
| 功能回归 | 中 | 执行完整回归测试 |

---

## 8. 附录：变更对比

### 8.1 API 变更表

| 原 API | 新 API | 变更类型 |
|--------|--------|---------|
| `PreCopyToScratch` | `PreCopyToBuffer` | 重命名 |
| `PostCopyFromScratch` | `PostCopyToOutput` | 重命名 |
| - | `PreCopyToBuffer(+sync)` | 新增重载 |
| - | `PostCopyToOutput(+sync)` | 新增重载 |
| - | `LocalDmaReduceCopy(+barrier)` | 新增重载 |
| `PreSyncIfMultiThread` | 保留 | 无变更 |
| `PostSyncIfMultiThread` | 保留 | 无变更 |
| `AicpuReduceBarrier` | 保留 | 无变更 |

### 8.2 代码量对比

| 指标 | 重构前 | 重构后 |
|------|--------|--------|
| wrapper 公共函数数 | 19 | 27 (+8) |
| 模板代码行数（5 个文件） | ~500 | ~420 (-80) |
| 内联 sync 调用点 | 16+ | 0 |
| 内联 barrier 调用点 | 6+ | 0（场景 A） |

### 8.3 优化效果

| 维度 | 效果 |
|------|------|
| **可维护性** | 公共逻辑集中维护，bug 修复只需修改 1 处 |
| **可读性** | 命名更准确，调用更简洁 |
| **可扩展性** | 新增算子模板可直接使用高层 API |
| **一致性** | 错误处理、边界判定统一 |

---

**文档版本**：v2.0  
**最后更新**：2026-06-21  
**审批状态**：待审批

---

**附录文件**：
- [alg_data_trans_wrapper.h](file:///d:/hccl-9.0.0-beta.2/copy/src/ops/op_common/template/wrapper/alg_data_trans_wrapper.h)
- [alg_data_trans_wrapper.cc](file:///d:/hccl-9.0.0-beta.2/copy/src/ops/op_common/template/wrapper/alg_data_trans_wrapper.cc)
- [OPTIMIZATION_ANALYSIS_V2.md](file:///d:/hccl-9.0.0-beta.2/copy/OPTIMIZATION_ANALYSIS_V2.md)
- [REFACTORING_REPORT.md](file:///d:/hccl-9.0.0-beta.2/copy/REFACTORING_REPORT.md)
