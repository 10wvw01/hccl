/**
 * Copyright (c) 2025 Huawei Technologies Co., Ltd.
 * 函数式 UnifiedDataTransfer 数据传输机制 - 核心数据结构与接口定义
 * 设计原则：无类结构、纯函数、数据不可变、模块化可复用
 */

#ifndef UNIFIED_DATA_TRANS_H
#define UNIFIED_DATA_TRANS_H

#include <vector>
#include <map>
#include <string>
#include "template_utils.h"
#include "alg_data_trans_wrapper.h"

namespace ops_hccl {

// ===== 基础数据结构（函数式风格，纯数据，无行为）=====

// 单段数据切片的偏移信息
struct SliceOffset {
    u64 offset{0};   // 相对基地址的偏移字节数
    u64 size{0};     // 数据大小（字节）
    u64 count{0};    // 数据元素个数

    SliceOffset() = default;
    SliceOffset(u64 off, u64 sz, u64 cnt) : offset(off), size(sz), count(cnt) {}
};

// 传输操作类型枚举
enum class TransOp {
    SENDRECV_WRITE,           // 双向写
    SENDRECV_READ,            // 双向读
    SEND_WRITE,               // 单向写（发送方）
    RECV_WRITE,               // 单向写（接收方）
    SEND_READ,                // 单向读（发送方）
    RECV_READ,                // 单向读（接收方）
    SENDRECV_WRITE_REDUCE,    // 双向写并归约
    SENDRECV_READ_REDUCE,     // 双向读并归约
    LOCAL_COPY,               // 本地拷贝
    LOCAL_REDUCE              // 本地归约
};

// 算法单步传输描述：一个 step 描述一次完整的数据传输操作
struct TransferStep {
    u32 srcRank{0};                       // 数据传输的源 rank 标识（rx 来源）
    u32 dstRank{0};                       // 数据传输的目标 rank 标识（tx 目标）
    std::vector<SliceOffset> txSlices;    // tx slice 的偏移地址信息列表
    std::vector<SliceOffset> rxSlices;    // rx slice 的偏移地址信息列表
    TransOp op{TransOp::SENDRECV_WRITE};  // 传输操作类型
    u32 threadIdx{0};                     // 使用的线程索引

    // 本地操作专用字段（LOCAL_COPY / LOCAL_REDUCE）
    // 当 op 为本地操作时，srcRank/dstRank 无意义，使用 localSrc/localDst
    SliceOffset localSrc;
    SliceOffset localDst;
};

// SliceInfoList：完整的算法传输计划，由算法生成器函数产生
using SliceInfoList = std::vector<TransferStep>;

// ===== 传输执行上下文 =====

// TransferContext：运行时执行所需的所有上下文信息（只读引用，函数式不可变）
struct TransferContext {
    const std::vector<ThreadHandle>& threads;
    const std::map<u32, std::vector<ChannelInfo>>& channels;
    const std::vector<u32>& rankList;       // rank 列表（algRank -> userRank 映射）
    const BuffInfo& buffInfo;
    HcclDataType dataType{HCCL_DATA_TYPE_INT8};
    HcclReduceOp reduceOp{HCCL_REDUCE_SUM};
    bool isDmaRead{false};                  // 是否使用 Read 模式（PCIe 链路）
    u64 hcclBuffBaseOff{0};                 // hcclBuffer 基偏移

    TransferContext(const std::vector<ThreadHandle>& t,
                    const std::map<u32, std::vector<ChannelInfo>>& ch,
                    const std::vector<u32>& rl,
                    const BuffInfo& bi,
                    HcclDataType dt,
                    HcclReduceOp ro,
                    bool read,
                    u64 baseOff)
        : threads(t), channels(ch), rankList(rl), buffInfo(bi),
          dataType(dt), reduceOp(ro), isDmaRead(read), hcclBuffBaseOff(baseOff) {}
};

// ===== 核心函数声明 =====

// UnifiedDataTransfer：基于 SliceInfoList 执行实际数据传输
// 输入：steps（算法生成的传输计划），ctx（执行上下文）
// 输出：HcclResult 执行结果
HcclResult UnifiedDataTransfer(const SliceInfoList& steps, const TransferContext& ctx);

// ===== 辅助函数声明 =====

// 根据算法 rank 索引获取实际 userRank
u32 GetRankFromList(const std::vector<u32>& rankList, u32 algRankIdx);

// 将 SliceOffset 转换为 DataSlice（基于指定基地址）
DataSlice MakeDataSlice(void* baseAddr, const SliceOffset& slice, u64 extraOffset);

// 判断传输操作是否为 Reduce 类型
inline bool IsReduceOp(TransOp op)
{
    return op == TransOp::SENDRECV_WRITE_REDUCE || op == TransOp::SENDRECV_READ_REDUCE ||
           op == TransOp::LOCAL_REDUCE;
}

// 判断传输操作是否为本地操作
inline bool IsLocalOp(TransOp op)
{
    return op == TransOp::LOCAL_COPY || op == TransOp::LOCAL_REDUCE;
}

// 判断传输操作是否为 Read 类型
inline bool IsReadOp(TransOp op)
{
    return op == TransOp::SENDRECV_READ || op == TransOp::SEND_READ ||
           op == TransOp::RECV_READ || op == TransOp::SENDRECV_READ_REDUCE;
}

// 判断传输操作是否为单向操作
inline bool IsUnidirectionalOp(TransOp op)
{
    return op == TransOp::SEND_WRITE || op == TransOp::RECV_WRITE ||
           op == TransOp::SEND_READ || op == TransOp::RECV_READ;
}

}  // namespace ops_hccl

#endif  // UNIFIED_DATA_TRANS_H
