/**
 * Copyright (c) 2025 Huawei Technologies Co., Ltd.
 * 函数式 Mesh 算法 SliceInfoList 生成器 - 实现
 * 逻辑等价于原有 Mesh 系列模板的步骤生成
 */

#include "mesh_slice_generator.h"

namespace ops_hccl {

// ===== 数据切分函数 =====

std::vector<SliceOffset> GenMeshOneShotSlices(const MeshAlgParam& param)
{
    // OneShot: 每个 rank 获得完整数据的相同切片，offset 按 rank 递增
    std::vector<SliceOffset> slices;
    slices.reserve(param.rankSize);

    u64 dataSize = param.count * param.dataTypeSize;
    u64 accumOff = 0;
    for (u32 rankIdx = 0; rankIdx < param.rankSize; ++rankIdx) {
        slices.emplace_back(accumOff, dataSize, param.count);
        accumOff += dataSize;
    }
    return slices;
}

std::vector<SliceOffset> GenMeshTwoShotSlices(const MeshAlgParam& param)
{
    // TwoShot: 数据按 rank 数量均衡切分
    std::vector<SliceOffset> slices;
    slices.reserve(param.rankSize);

    u64 sliceCount = RoundUp(param.count, param.rankSize);
    u64 sliceSize = sliceCount * param.dataTypeSize;

    u64 offsetCount = 0;
    u64 offsetSize = 0;
    for (u32 sliceIdx = 0; sliceIdx < param.rankSize; ++sliceIdx) {
        if (param.count - offsetCount > sliceCount) {
            slices.emplace_back(offsetSize, sliceSize, sliceCount);
            offsetCount += sliceCount;
            offsetSize = offsetCount * param.dataTypeSize;
        } else {
            u64 curSliceCount = param.count - offsetCount;
            u64 curSliceSize = curSliceCount * param.dataTypeSize;
            slices.emplace_back(offsetSize, curSliceSize, curSliceCount);
            offsetCount = param.count;
            offsetSize = offsetCount * param.dataTypeSize;
        }
    }
    return slices;
}

// ===== Mesh OneShot AllReduce 步骤生成 =====

SliceInfoList GenMeshOneShotAllReduceSteps(const MeshAlgParam& param,
                                           const std::vector<SliceOffset>& dataSlices,
                                           bool isDmaRead)
{
    SliceInfoList steps;

    // 阶段1：主线程 LocalCopy（input -> output）
    if (param.rankSize >= 1 && !dataSlices.empty()) {
        TransferStep localCopyStep;
        localCopyStep.op = TransOp::LOCAL_COPY;
        localCopyStep.threadIdx = 0;
        localCopyStep.localSrc = dataSlices[param.myRankIdx];
        localCopyStep.localDst = dataSlices[param.myRankIdx];
        steps.push_back(std::move(localCopyStep));
    }

    // 特殊场景：只有 1 个 rank，无需通信
    if (param.rankSize == 1) {
        return steps;
    }

    // 阶段2：各从线程并行 SendRecvWrite（与每个远端 rank 双向写）
    // 从线程索引 = queIdx（1 到 rankSize-1），对应远端 rank = (myRankIdx + queIdx) % rankSize
    for (u32 queIdx = 1; queIdx < param.rankSize; ++queIdx) {
        u32 nextRank = (param.myRankIdx + queIdx) % param.rankSize;

        TransferStep step;
        step.srcRank = nextRank;  // rx 来源
        step.dstRank = nextRank;  // tx 目标
        step.threadIdx = queIdx;  // 使用对应从线程

        // tx: 本地 input -> 远端 hcclBuffer（本 rank 的数据片）
        step.txSlices.push_back(dataSlices[param.myRankIdx]);
        // rx: 远端 input -> 本地 hcclBuffer（远端 rank 的数据片）
        step.rxSlices.push_back(dataSlices[nextRank]);

        step.op = isDmaRead ? TransOp::SENDRECV_READ : TransOp::SENDRECV_WRITE;
        steps.push_back(std::move(step));
    }

    // 阶段3：主线程 LocalReduce（将各远端数据归约到 output）
    for (u32 rankIdx = 0; rankIdx < param.rankSize; ++rankIdx) {
        if (rankIdx == param.myRankIdx) {
            continue;
        }
        TransferStep reduceStep;
        reduceStep.op = TransOp::LOCAL_REDUCE;
        reduceStep.threadIdx = 0;
        // src: hcclBuffer 中远端 rank 的数据片
        reduceStep.localSrc = dataSlices[rankIdx];
        // dst: output 中本 rank 的数据片
        reduceStep.localDst = dataSlices[param.myRankIdx];
        steps.push_back(std::move(reduceStep));
    }

    return steps;
}

// ===== Mesh TwoShot ReduceScatter 步骤生成 =====

SliceInfoList GenMeshTwoShotScatterSteps(const MeshAlgParam& param,
                                         const std::vector<SliceOffset>& dataSlices)
{
    SliceInfoList steps;
    u64 recvSize = dataSlices[param.myRankIdx].size;

    for (u32 remoteIdx = 0; remoteIdx < param.rankSize; ++remoteIdx) {
        u64 sendSize = dataSlices[remoteIdx].size;

        // 发送和接收数据量都为 0 时跳过
        if (sendSize == 0 && recvSize == 0) {
            continue;
        }

        TransferStep step;
        step.threadIdx = remoteIdx;  // Mesh TwoShot 每个远端 rank 用对应线程

        if (remoteIdx == param.myRankIdx) {
            // 本地拷贝：input -> hcclBuffer
            step.op = TransOp::LOCAL_COPY;
            step.localSrc = dataSlices[remoteIdx];
            // dst 偏移 = remoteIdx * recvSize（在 hcclBuffer 中的位置）
            step.localDst = SliceOffset(remoteIdx * recvSize, recvSize, dataSlices[param.myRankIdx].count);
        } else {
            // 跨 rank 通信
            step.srcRank = remoteIdx;  // rx 来源
            step.dstRank = remoteIdx;  // tx 目标

            // tx: 本地 input 的 remoteIdx 切片 -> 远端 hcclBuffer 的 myRankIdx 位置
            step.txSlices.push_back(dataSlices[remoteIdx]);
            // rx: 远端 input 的 myRankIdx 切片 -> 本地 hcclBuffer 的 remoteIdx 位置
            step.rxSlices.push_back(dataSlices[param.myRankIdx]);

            // 根据发送/接收数据量选择操作类型
            if (sendSize == 0) {
                step.op = TransOp::RECV_WRITE;  // 只接收
            } else if (recvSize == 0) {
                step.op = TransOp::SEND_WRITE;  // 只发送
            } else {
                step.op = TransOp::SENDRECV_WRITE;  // 双向写
            }
        }
        steps.push_back(std::move(step));
    }
    return steps;
}

// ===== Mesh TwoShot 本地归约步骤生成 =====

SliceInfoList GenMeshTwoShotLocalReduceSteps(const MeshAlgParam& param,
                                             const std::vector<SliceOffset>& dataSlices)
{
    SliceInfoList steps;
    u64 sliceSize = dataSlices[param.myRankIdx].size;
    u64 sliceCount = dataSlices[param.myRankIdx].count;

    // 数据量为 0 时无需 Reduce
    if (sliceSize == 0) {
        return steps;
    }

    // 每片数据 Reduce 到第 0 片数据的位置
    for (u32 sliceIdx = 1; sliceIdx < param.rankSize; ++sliceIdx) {
        TransferStep step;
        step.op = TransOp::LOCAL_REDUCE;
        step.threadIdx = 0;
        // src: hcclBuffer 中 sliceIdx 位置的数据
        step.localSrc = SliceOffset(sliceIdx * sliceSize, sliceSize, sliceCount);
        // dst: hcclBuffer 中第 0 片位置的数据
        step.localDst = SliceOffset(0, sliceSize, sliceCount);
        steps.push_back(std::move(step));
    }
    return steps;
}

// ===== Mesh TwoShot AllGather 步骤生成 =====

SliceInfoList GenMeshTwoShotGatherSteps(const MeshAlgParam& param,
                                        const std::vector<SliceOffset>& dataSlices)
{
    SliceInfoList steps;
    u64 sendSize = dataSlices[param.myRankIdx].size;

    for (u32 remoteIdx = 0; remoteIdx < param.rankSize; ++remoteIdx) {
        u64 recvSize = dataSlices[remoteIdx].size;

        if (sendSize == 0 && recvSize == 0) {
            continue;
        }

        TransferStep step;
        step.threadIdx = remoteIdx;

        if (remoteIdx == param.myRankIdx) {
            // 本地拷贝：hcclBuffer -> output
            step.op = TransOp::LOCAL_COPY;
            step.localSrc = SliceOffset(0, sendSize, dataSlices[param.myRankIdx].count);
            step.localDst = dataSlices[remoteIdx];
        } else {
            step.srcRank = remoteIdx;
            step.dstRank = remoteIdx;

            // tx: 本地 hcclBuffer 第 0 片 -> 远端 output 的 myRankIdx 偏移
            step.txSlices.push_back(SliceOffset(0, sendSize, dataSlices[param.myRankIdx].count));
            // rx: 远端 hcclBuffer 第 0 片 -> 本地 output 的 remoteIdx 偏移
            step.rxSlices.push_back(SliceOffset(0, recvSize, dataSlices[remoteIdx].count));

            // AllGather 阶段使用 Read 模式
            if (sendSize == 0) {
                step.op = TransOp::RECV_READ;
            } else if (recvSize == 0) {
                step.op = TransOp::SEND_READ;
            } else {
                step.op = TransOp::SENDRECV_READ;
            }
        }
        steps.push_back(std::move(step));
    }
    return steps;
}

// ===== Mesh AllGather 步骤生成 =====

SliceInfoList GenMeshAllGatherSteps(u32 rankSize, u32 myRankIdx,
                                    u64 sliceSize, u64 tailSize,
                                    bool isDmaRead)
{
    SliceInfoList steps;

    for (u32 remoteIdx = 0; remoteIdx < rankSize; ++remoteIdx) {
        u64 curSliceSize = (remoteIdx == rankSize - 1 && tailSize != 0) ? tailSize : sliceSize;
        u64 curSliceCount = curSliceSize;  // AllGather 中 count = size

        TransferStep step;
        step.threadIdx = (remoteIdx == myRankIdx) ? 0 : remoteIdx;

        if (remoteIdx == myRankIdx) {
            // 本地拷贝
            step.op = TransOp::LOCAL_COPY;
            step.localSrc = SliceOffset(sliceSize * myRankIdx, curSliceSize, curSliceCount);
            step.localDst = SliceOffset(sliceSize * myRankIdx, curSliceSize, curSliceCount);
        } else {
            step.srcRank = remoteIdx;
            step.dstRank = remoteIdx;
            // tx: 本 rank 的数据 -> 远端
            step.txSlices.emplace_back(sliceSize * myRankIdx, curSliceSize, curSliceCount);
            // rx: 远端 -> 本地
            step.rxSlices.emplace_back(sliceSize * remoteIdx, curSliceSize, curSliceCount);
            step.op = isDmaRead ? TransOp::SENDRECV_READ : TransOp::SENDRECV_WRITE;
        }
        steps.push_back(std::move(step));
    }
    return steps;
}

// ===== Mesh ReduceScatter 步骤生成 =====

SliceInfoList GenMeshReduceScatterSteps(const MeshAlgParam& param,
                                        const std::vector<SliceOffset>& dataSlices,
                                        bool isDmaRead)
{
    SliceInfoList steps;
    u64 recvSize = dataSlices[param.myRankIdx].size;

    for (u32 remoteIdx = 0; remoteIdx < param.rankSize; ++remoteIdx) {
        u64 sendSize = dataSlices[remoteIdx].size;
        if (sendSize == 0 && recvSize == 0) {
            continue;
        }

        TransferStep step;
        step.threadIdx = remoteIdx;

        if (remoteIdx == param.myRankIdx) {
            step.op = TransOp::LOCAL_COPY;
            step.localSrc = dataSlices[remoteIdx];
            step.localDst = SliceOffset(0, recvSize, dataSlices[param.myRankIdx].count);
        } else {
            step.srcRank = remoteIdx;
            step.dstRank = remoteIdx;
            step.txSlices.push_back(dataSlices[remoteIdx]);
            step.rxSlices.push_back(dataSlices[param.myRankIdx]);
            if (sendSize == 0) {
                step.op = isDmaRead ? TransOp::RECV_READ : TransOp::RECV_WRITE;
            } else if (recvSize == 0) {
                step.op = isDmaRead ? TransOp::SEND_READ : TransOp::SEND_WRITE;
            } else {
                step.op = isDmaRead ? TransOp::SENDRECV_READ : TransOp::SENDRECV_WRITE;
            }
        }
        steps.push_back(std::move(step));
    }

    // 添加本地归约步骤
    if (recvSize > 0) {
        for (u32 sliceIdx = 1; sliceIdx < param.rankSize; ++sliceIdx) {
            TransferStep reduceStep;
            reduceStep.op = TransOp::LOCAL_REDUCE;
            reduceStep.threadIdx = 0;
            reduceStep.localSrc = SliceOffset(sliceIdx * recvSize, recvSize, dataSlices[param.myRankIdx].count);
            reduceStep.localDst = SliceOffset(0, recvSize, dataSlices[param.myRankIdx].count);
            steps.push_back(std::move(reduceStep));
        }
    }
    return steps;
}

// ===== Mesh Broadcast 步骤生成 =====

SliceInfoList GenMeshBroadcastSteps(u32 rankSize, u32 myRankIdx, u32 root,
                                    u64 sliceSize, bool isDmaRead)
{
    SliceInfoList steps;

    if (myRankIdx == root) {
        // root 端：向所有其他 rank 发送数据
        for (u32 remoteIdx = 0; remoteIdx < rankSize; ++remoteIdx) {
            if (remoteIdx == myRankIdx) {
                continue;
            }
            TransferStep step;
            step.srcRank = remoteIdx;
            step.dstRank = remoteIdx;
            step.threadIdx = remoteIdx;
            step.txSlices.emplace_back(0, sliceSize, sliceSize);
            step.rxSlices.emplace_back(0, sliceSize, sliceSize);
            step.op = isDmaRead ? TransOp::SEND_READ : TransOp::SEND_WRITE;
            steps.push_back(std::move(step));
        }
    } else {
        // 非 root 端：从 root 接收数据
        TransferStep step;
        step.srcRank = root;
        step.dstRank = root;
        step.threadIdx = 0;
        step.txSlices.emplace_back(0, sliceSize, sliceSize);
        step.rxSlices.emplace_back(0, sliceSize, sliceSize);
        step.op = isDmaRead ? TransOp::RECV_READ : TransOp::RECV_WRITE;
        steps.push_back(std::move(step));
    }
    return steps;
}

}  // namespace ops_hccl
