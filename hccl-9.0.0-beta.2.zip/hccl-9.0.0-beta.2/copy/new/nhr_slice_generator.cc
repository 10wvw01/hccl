/**
 * Copyright (c) 2025 Huawei Technologies Co., Ltd.
 * 函数式 NHR 算法 SliceInfoList 生成器 - 实现
 * 逻辑等价于原有 InsTempAllReduceNHR / InsTempAllGatherNHR 的步骤生成
 */

#include "nhr_slice_generator.h"

namespace ops_hccl {

// ===== 辅助函数实现 =====

u32 CalcNhrStepNum(u32 rankSize)
{
    u32 nSteps = 0;
    for (u32 tmp = rankSize - 1; tmp != 0; tmp >>= 1, nSteps++) {
    }
    return nSteps;
}

std::pair<std::vector<u32>, std::vector<u32>> GenNhrReduceScatterSliceIdxs(
    u32 rankSize, u32 myRankIdx, u32 step)
{
    // 通信对象
    u32 deltaRank = 1 << step;
    // txSliceIdx 起始 = sendToIdx, rxSliceIdx 起始 = myRankIdx
    u32 txSliceIdx = (myRankIdx + rankSize - deltaRank) % rankSize;
    u32 rxSliceIdx = myRankIdx;

    // 数据份数和编号增量
    u32 nSlices = (rankSize - 1 + (1 << step)) / (1 << (step + 1));
    u32 deltaSliceIndex = 1 << (step + 1);

    std::vector<u32> txSliceIdxs;
    std::vector<u32> rxSliceIdxs;
    txSliceIdxs.reserve(nSlices);
    rxSliceIdxs.reserve(nSlices);

    for (u32 i = 0; i < nSlices; i++) {
        txSliceIdxs.push_back(txSliceIdx);
        rxSliceIdxs.push_back(rxSliceIdx);
        txSliceIdx = (txSliceIdx + rankSize - deltaSliceIndex) % rankSize;
        rxSliceIdx = (rxSliceIdx + rankSize - deltaSliceIndex) % rankSize;
    }
    return {txSliceIdxs, rxSliceIdxs};
}

std::pair<std::vector<u32>, std::vector<u32>> GenNhrAllGatherSliceIdxs(
    u32 rankSize, u32 myRankIdx, u32 step, u32 nSteps)
{
    // 通信对象
    u32 deltaRank = 1 << (nSteps - 1 - step);
    // txSliceIdx 起始 = myRankIdx, rxSliceIdx 起始
    u32 txSliceIdx = myRankIdx;
    u32 rxSliceIdx = (myRankIdx - (1 << (nSteps - 1 - step)) + rankSize) % rankSize;

    // 数据份数和编号增量
    u32 nSlices = (rankSize - 1 + (1 << (nSteps - 1 - step))) / (1 << (nSteps - step));
    u32 deltaSliceIndex = 1 << (nSteps - step);

    std::vector<u32> txSliceIdxs;
    std::vector<u32> rxSliceIdxs;
    txSliceIdxs.reserve(nSlices);
    rxSliceIdxs.reserve(nSlices);

    for (u32 i = 0; i < nSlices; i++) {
        txSliceIdxs.push_back(txSliceIdx);
        rxSliceIdxs.push_back(rxSliceIdx);
        txSliceIdx = (txSliceIdx + rankSize - deltaSliceIndex) % rankSize;
        rxSliceIdx = (rxSliceIdx + rankSize - deltaSliceIndex) % rankSize;
    }
    return {txSliceIdxs, rxSliceIdxs};
}

// ===== 数据切分函数 =====

std::vector<SliceOffset> GenNhrDataSlices(const NhrAlgParam& param)
{
    u32 sliceNum = param.rankSize;
    std::vector<SliceOffset> slices;
    slices.reserve(sliceNum);

    u64 sliceCount = RoundUp(param.count, sliceNum);
    u64 sliceSize = sliceCount * param.dataTypeSize;

    u64 offsetCount = 0;
    u64 offsetSize = 0;
    for (u32 sliceIdx = 0; sliceIdx < sliceNum; ++sliceIdx) {
        if (param.count - offsetCount > sliceCount) {
            slices.emplace_back(offsetSize, sliceSize, sliceCount);
            offsetCount += sliceCount;
            offsetSize = offsetCount * param.dataTypeSize;
        } else {
            u64 curSliceCount = param.count - offsetCount;
            u64 curSliceSize = curSliceCount * param.dataTypeSize;
            slices.emplace_back(offsetSize, curSliceSize, curSliceCount);
            offsetCount = param.count;
            offsetSize = offsetCount * param.dataTypeSize;
        }
    }
    return slices;
}

// ===== NHR ReduceScatter 阶段步骤生成 =====

SliceInfoList GenNhrReduceScatterSteps(const NhrAlgParam& param,
                                       const std::vector<SliceOffset>& dataSlices,
                                       bool isDmaRead)
{
    SliceInfoList steps;
    u32 nSteps = CalcNhrStepNum(param.rankSize);
    steps.reserve(nSteps);

    for (u32 step = 0; step < nSteps; ++step) {
        u32 deltaRank = 1 << step;
        u32 sendToIdx = (param.myRankIdx + param.rankSize - deltaRank) % param.rankSize;
        u32 recvFromIdx = (param.myRankIdx + deltaRank) % param.rankSize;

        auto [txSliceIdxs, rxSliceIdxs] = GenNhrReduceScatterSliceIdxs(
            param.rankSize, param.myRankIdx, step);

        TransferStep transferStep;
        transferStep.srcRank = recvFromIdx;   // rx 来源 rank
        transferStep.dstRank = sendToIdx;     // tx 目标 rank
        transferStep.threadIdx = 0;           // NHR 单线程

        // 根据 slice 索引填充 tx/rx 切片偏移
        for (u32 i = 0; i < txSliceIdxs.size(); ++i) {
            u32 txIdx = txSliceIdxs[i];
            if (txIdx < dataSlices.size()) {
                transferStep.txSlices.push_back(dataSlices[txIdx]);
            }
        }
        for (u32 i = 0; i < rxSliceIdxs.size(); ++i) {
            u32 rxIdx = rxSliceIdxs[i];
            if (rxIdx < dataSlices.size()) {
                transferStep.rxSlices.push_back(dataSlices[rxIdx]);
            }
        }

        // ReduceScatter 阶段使用 Reduce 操作
        transferStep.op = isDmaRead ? TransOp::SENDRECV_READ_REDUCE : TransOp::SENDRECV_WRITE_REDUCE;

        steps.push_back(std::move(transferStep));
    }
    return steps;
}

// ===== NHR AllGather 阶段步骤生成 =====

SliceInfoList GenNhrAllGatherSteps(const NhrAlgParam& param,
                                   const std::vector<SliceOffset>& dataSlices,
                                   bool isDmaRead)
{
    SliceInfoList steps;
    u32 nSteps = CalcNhrStepNum(param.rankSize);
    steps.reserve(nSteps);

    for (u32 step = 0; step < nSteps; ++step) {
        u32 deltaRank = 1 << (nSteps - 1 - step);
        u32 sendToIdx = (param.myRankIdx + deltaRank) % param.rankSize;
        u32 recvFromIdx = (param.myRankIdx + param.rankSize - deltaRank) % param.rankSize;

        auto [txSliceIdxs, rxSliceIdxs] = GenNhrAllGatherSliceIdxs(
            param.rankSize, param.myRankIdx, step, nSteps);

        TransferStep transferStep;
        transferStep.srcRank = recvFromIdx;
        transferStep.dstRank = sendToIdx;
        transferStep.threadIdx = 0;

        for (u32 i = 0; i < txSliceIdxs.size(); ++i) {
            u32 txIdx = txSliceIdxs[i];
            if (txIdx < dataSlices.size()) {
                transferStep.txSlices.push_back(dataSlices[txIdx]);
            }
        }
        for (u32 i = 0; i < rxSliceIdxs.size(); ++i) {
            u32 rxIdx = rxSliceIdxs[i];
            if (rxIdx < dataSlices.size()) {
                transferStep.rxSlices.push_back(dataSlices[rxIdx]);
            }
        }

        // AllGather 阶段不使用 Reduce
        transferStep.op = isDmaRead ? TransOp::SENDRECV_READ : TransOp::SENDRECV_WRITE;

        steps.push_back(std::move(transferStep));
    }
    return steps;
}

// ===== NHR AllGather（独立算子）步骤生成 =====

SliceInfoList GenNhrAllGatherOnlySteps(u32 rankSize, u32 myRankIdx,
                                       u64 sliceSize, u64 tailSize,
                                       u32 repeatNum, bool isDmaRead)
{
    SliceInfoList steps;
    u32 nSteps = CalcNhrStepNum(rankSize);

    for (u32 rpt = 0; rpt < repeatNum; ++rpt) {
        for (u32 step = 0; step < nSteps; ++step) {
            u32 deltaRank = 1 << (nSteps - 1 - step);
            u32 sendToIdx = (myRankIdx + deltaRank) % rankSize;
            u32 recvFromIdx = (myRankIdx + rankSize - deltaRank) % rankSize;

            auto [txSliceIdxs, rxSliceIdxs] = GenNhrAllGatherSliceIdxs(
                rankSize, myRankIdx, step, nSteps);

            TransferStep transferStep;
            transferStep.srcRank = recvFromIdx;
            transferStep.dstRank = sendToIdx;
            transferStep.threadIdx = 0;

            for (u32 i = 0; i < txSliceIdxs.size(); ++i) {
                u32 txIdx = txSliceIdxs[i];
                u64 curSliceSize = (txIdx == rankSize - 1 && tailSize != 0) ? tailSize : sliceSize;
                u64 curSliceCount = curSliceSize;  // 独立 AllGather 中 count = size
                // 偏移 = sliceSize * txIdx（基于 repeat 内的 scratch 基地址）
                transferStep.txSlices.emplace_back(sliceSize * txIdx, curSliceSize, curSliceCount);
            }
            for (u32 i = 0; i < rxSliceIdxs.size(); ++i) {
                u32 rxIdx = rxSliceIdxs[i];
                u64 curSliceSize = (rxIdx == rankSize - 1 && tailSize != 0) ? tailSize : sliceSize;
                u64 curSliceCount = curSliceSize;
                transferStep.rxSlices.emplace_back(sliceSize * rxIdx, curSliceSize, curSliceCount);
            }

            transferStep.op = isDmaRead ? TransOp::SENDRECV_READ : TransOp::SENDRECV_WRITE;
            steps.push_back(std::move(transferStep));
        }
    }
    return steps;
}

}  // namespace ops_hccl
