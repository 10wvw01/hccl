/**
 * Copyright (c) 2025 Huawei Technologies Co., Ltd.
 * 函数式 Mesh 算法 SliceInfoList 生成器 - 接口定义
 * 职责：以纯函数形式生成 Mesh 算法的传输计划 SliceInfoList
 * 设计原则：无类结构、纯函数、输入输出明确、算法逻辑与原有实现一致
 */

#ifndef MESH_SLICE_GENERATOR_H
#define MESH_SLICE_GENERATOR_H

#include "unified_data_trans.h"

namespace ops_hccl {

// ===== Mesh 算法参数（纯数据结构）=====

struct MeshAlgParam {
    u32 rankSize;       // 参与 Mesh 通信的 rank 总数
    u32 myRankIdx;      // 本 rank 在 rank 列表中的索引
    u64 count;          // 数据元素总数
    u64 dataTypeSize;   // 单个数据元素大小（字节）

    MeshAlgParam(u32 rs, u32 idx, u64 cnt, u64 dts)
        : rankSize(rs), myRankIdx(idx), count(cnt), dataTypeSize(dts) {}
};

// ===== 数据切分函数 =====

// Mesh OneShot 数据切分：每个 rank 获得相同大小的完整数据副本
// 逻辑等价于原 InsTempAllReduceMesh1DOneShot::CalcSlice()
std::vector<SliceOffset> GenMeshOneShotSlices(const MeshAlgParam& param);

// Mesh TwoShot 数据切分：数据按 rank 数量均衡切分
// 逻辑等价于原 InsTempAllReduceMesh1DTwoShot::SplitData()
std::vector<SliceOffset> GenMeshTwoShotSlices(const MeshAlgParam& param);

// ===== Mesh OneShot AllReduce 步骤生成 =====

// 生成 Mesh OneShot AllReduce 的 SliceInfoList
// 阶段1：主线程 LocalCopy（input -> output）
// 阶段2：各从线程并行 SendRecvWrite（与每个远端 rank 双向写）
// 阶段3：主线程 LocalReduce（将各远端数据归约到 output）
// 逻辑等价于原 InsTempAllReduceMesh1DOneShot::KernelRun()
SliceInfoList GenMeshOneShotAllReduceSteps(const MeshAlgParam& param,
                                           const std::vector<SliceOffset>& dataSlices,
                                           bool isDmaRead);

// ===== Mesh TwoShot AllReduce 步骤生成 =====

// 生成 Mesh TwoShot ReduceScatter 阶段的 SliceInfoList
// 每个远端 rank 对应一个 step：SendRecvWrite / SendWrite / RecvWrite / LocalCopy
// 逻辑等价于原 InsTempAllReduceMesh1DTwoShot::ScatterData()
SliceInfoList GenMeshTwoShotScatterSteps(const MeshAlgParam& param,
                                         const std::vector<SliceOffset>& dataSlices);

// 生成 Mesh TwoShot 本地归约步骤的 SliceInfoList
// 将各 slice 归约到 slice 0 的位置
// 逻辑等价于原 InsTempAllReduceMesh1DTwoShot::ReduceData()
SliceInfoList GenMeshTwoShotLocalReduceSteps(const MeshAlgParam& param,
                                             const std::vector<SliceOffset>& dataSlices);

// 生成 Mesh TwoShot AllGather 阶段的 SliceInfoList
// 每个远端 rank 对应一个 step：SendRecvRead / SendRead / RecvRead / LocalCopy
// 逻辑等价于原 InsTempAllReduceMesh1DTwoShot::GatherData()
SliceInfoList GenMeshTwoShotGatherSteps(const MeshAlgParam& param,
                                        const std::vector<SliceOffset>& dataSlices);

// ===== Mesh AllGather 步骤生成 =====

// 生成 Mesh AllGather 的 SliceInfoList
// 每个 rank 对应一个 step：SendRecvWrite / LocalCopy
// 逻辑等价于原 InsTempAllGatherMesh1D::KernelRun()
SliceInfoList GenMeshAllGatherSteps(u32 rankSize, u32 myRankIdx,
                                    u64 sliceSize, u64 tailSize,
                                    bool isDmaRead);

// ===== Mesh ReduceScatter 步骤生成 =====

// 生成 Mesh ReduceScatter 的 SliceInfoList
// 逻辑等价于原 InsTempReduceScatterMesh1D::KernelRun()
SliceInfoList GenMeshReduceScatterSteps(const MeshAlgParam& param,
                                        const std::vector<SliceOffset>& dataSlices,
                                        bool isDmaRead);

// ===== Mesh Broadcast 步骤生成 =====

// 生成 Mesh Broadcast 的 SliceInfoList
// 逻辑等价于原 InsTempBroadcastMesh1DTwoShot::KernelRun()
SliceInfoList GenMeshBroadcastSteps(u32 rankSize, u32 myRankIdx, u32 root,
                                    u64 sliceSize, bool isDmaRead);

}  // namespace ops_hccl

#endif  // MESH_SLICE_GENERATOR_H
