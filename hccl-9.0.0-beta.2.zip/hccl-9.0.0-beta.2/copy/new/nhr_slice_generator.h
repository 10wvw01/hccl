/**
 * Copyright (c) 2025 Huawei Technologies Co., Ltd.
 * 函数式 NHR 算法 SliceInfoList 生成器 - 接口定义
 * 职责：以纯函数形式生成 NHR 算法的传输计划 SliceInfoList
 * 设计原则：无类结构、纯函数、输入输出明确、算法逻辑与原有实现一致
 */

#ifndef NHR_SLICE_GENERATOR_H
#define NHR_SLICE_GENERATOR_H

#include "unified_data_trans.h"

namespace ops_hccl {

// ===== NHR 算法参数（纯数据结构）=====

struct NhrAlgParam {
    u32 rankSize;       // 参与 NHR 通信的 rank 总数
    u32 myRankIdx;      // 本 rank 在 rank 列表中的索引
    u64 count;          // 数据元素总数
    u64 dataTypeSize;   // 单个数据元素大小（字节）

    NhrAlgParam(u32 rs, u32 idx, u64 cnt, u64 dts)
        : rankSize(rs), myRankIdx(idx), count(cnt), dataTypeSize(dts) {}
};

// ===== 数据切分函数 =====

// 将数据按 rank 数量均衡切分为 SliceOffset 列表
// 逻辑等价于原 InsTempAllReduceNHR::SplitData()
std::vector<SliceOffset> GenNhrDataSlices(const NhrAlgParam& param);

// ===== NHR ReduceScatter 阶段步骤生成 =====

// 生成 NHR ReduceScatter 阶段的 SliceInfoList
// 每步包含：srcRank（rx来源）、dstRank（tx目标）、txSlices、rxSlices
// 传输操作类型：SendRecvWriteReduce 或 SendRecvReadReduce（取决于 isDmaRead）
// 逻辑等价于原 InsTempAllReduceNHR::GetReduceScatterStepInfoList() + RunReduceScatter()
SliceInfoList GenNhrReduceScatterSteps(const NhrAlgParam& param,
                                       const std::vector<SliceOffset>& dataSlices,
                                       bool isDmaRead);

// ===== NHR AllGather 阶段步骤生成 =====

// 生成 NHR AllGather 阶段的 SliceInfoList
// 每步包含：srcRank（rx来源）、dstRank（tx目标）、txSlices、rxSlices
// 传输操作类型：SendRecvWrite 或 SendRecvRead（取决于 isDmaRead）
// 逻辑等价于原 InsTempAllReduceNHR::GetAllGatherStepInfoList() + RunAllGather()
SliceInfoList GenNhrAllGatherSteps(const NhrAlgParam& param,
                                   const std::vector<SliceOffset>& dataSlices,
                                   bool isDmaRead);

// ===== NHR AllGather（独立算子）步骤生成 =====

// 生成独立 AllGather NHR 算法的 SliceInfoList
// 支持尾块模式（tailSize != 0）和 repeat 模式
// 逻辑等价于原 InsTempAllGatherNHR::RunAllGatherNHR()
SliceInfoList GenNhrAllGatherOnlySteps(u32 rankSize, u32 myRankIdx,
                                       u64 sliceSize, u64 tailSize,
                                       u32 repeatNum, bool isDmaRead);

// ===== NHR 辅助函数 =====

// 计算 NHR 算法通信步数：ceil(log2(rankSize))
u32 CalcNhrStepNum(u32 rankSize);

// 生成 NHR ReduceScatter 单步的 slice 索引
// 返回值：pair<txSliceIdxs, rxSliceIdxs>
std::pair<std::vector<u32>, std::vector<u32>> GenNhrReduceScatterSliceIdxs(
    u32 rankSize, u32 myRankIdx, u32 step);

// 生成 NHR AllGather 单步的 slice 索引
// 返回值：pair<txSliceIdxs, rxSliceIdxs>
std::pair<std::vector<u32>, std::vector<u32>> GenNhrAllGatherSliceIdxs(
    u32 rankSize, u32 myRankIdx, u32 step, u32 nSteps);

}  // namespace ops_hccl

#endif  // NHR_SLICE_GENERATOR_H
