/**
 * Copyright (c) 2025 Huawei Technologies Co., Ltd.
 * 函数式 UnifiedDataTransfer 使用示例
 * 展示算法模板与 UnifiedDataTransfer 之间的清晰接口与数据流转路径
 *
 * 数据流转路径：
 *   算法参数 → GenXxxSteps() → SliceInfoList → UnifiedDataTransfer() → 底层 wrapper
 *
 * 接口分层：
 *   1. 算法生成层（nhr_slice_generator / mesh_slice_generator）：纯函数，生成传输计划
 *   2. 传输执行层（unified_data_trans）：消费传输计划，执行实际数据传输
 *   3. 底层原语层（alg_data_trans_wrapper）：Hcomm*OnThread 系列底层调用
 */

#include "unified_data_trans.h"
#include "nhr_slice_generator.h"
#include "mesh_slice_generator.h"

namespace ops_hccl {

// ===== NHR AllReduce 示例 =====
// 等价于原 InsTempAllReduceNHR::KernelRun() 的核心逻辑
HcclResult RunNhrAllReduceExample(const OpParam& param,
                                  const TemplateDataParams& tempAlgParams,
                                  TemplateResource& templateResource,
                                  const std::vector<u32>& rankList)
{
    // 1. 准备算法参数
    u32 myRankIdx = 0;
    CHK_RET(GetAlgRank(param.myRank, rankList, myRankIdx));
    u64 dataTypeSize = DATATYPE_SIZE_TABLE[param.DataDes.dataType];
    NhrAlgParam nhrParam(rankList.size(), myRankIdx, tempAlgParams.count, dataTypeSize);

    // 2. 判断传输模式（PCIe 链路使用 Read 模式）
    bool isDmaRead = IsPcieProtocol(templateResource.channels);

    // 3. 生成数据切片
    std::vector<SliceOffset> dataSlices = GenNhrDataSlices(nhrParam);

    // 4. 构造传输上下文
    TransferContext ctx(templateResource.threads, templateResource.channels, rankList,
                        tempAlgParams.buffInfo, param.DataDes.dataType, param.reduceType,
                        isDmaRead, tempAlgParams.buffInfo.hcclBuffBaseOff);

    // 5. PreCopy：input -> hcclBuffer
    {
        SliceInfoList preCopySteps;
        TransferStep step;
        step.op = TransOp::LOCAL_COPY;
        step.threadIdx = 0;
        step.localSrc = SliceOffset(tempAlgParams.buffInfo.inBuffBaseOff, tempAlgParams.sliceSize, tempAlgParams.count);
        step.localDst = SliceOffset(tempAlgParams.buffInfo.hcclBuffBaseOff, tempAlgParams.sliceSize, tempAlgParams.count);
        preCopySteps.push_back(std::move(step));
        CHK_RET(UnifiedDataTransfer(preCopySteps, ctx));
    }

    // 6. ReduceScatter 阶段：生成步骤并执行
    SliceInfoList reduceScatterSteps = GenNhrReduceScatterSteps(nhrParam, dataSlices, isDmaRead);
    CHK_RET(UnifiedDataTransfer(reduceScatterSteps, ctx));

    // 7. AllGather 阶段：生成步骤并执行
    SliceInfoList allGatherSteps = GenNhrAllGatherSteps(nhrParam, dataSlices, isDmaRead);
    CHK_RET(UnifiedDataTransfer(allGatherSteps, ctx));

    // 8. PostCopy：hcclBuffer -> output
    {
        SliceInfoList postCopySteps;
        TransferStep step;
        step.op = TransOp::LOCAL_COPY;
        step.threadIdx = 0;
        step.localSrc = SliceOffset(tempAlgParams.buffInfo.hcclBuffBaseOff, tempAlgParams.sliceSize, tempAlgParams.count);
        step.localDst = SliceOffset(tempAlgParams.buffInfo.outBuffBaseOff, tempAlgParams.sliceSize, tempAlgParams.count);
        postCopySteps.push_back(std::move(step));
        CHK_RET(UnifiedDataTransfer(postCopySteps, ctx));
    }

    return HCCL_SUCCESS;
}

// ===== Mesh OneShot AllReduce 示例 =====
// 等价于原 InsTempAllReduceMesh1DOneShot::KernelRun() 的核心逻辑
HcclResult RunMeshOneShotAllReduceExample(const OpParam& param,
                                          const TemplateDataParams& tempAlgParams,
                                          TemplateResource& templateResource,
                                          const std::vector<u32>& rankList)
{
    // 1. 准备算法参数
    u32 myRankIdx = 0;
    CHK_RET(GetAlgRank(param.myRank, rankList, myRankIdx));
    u64 dataTypeSize = DATATYPE_SIZE_TABLE[param.DataDes.dataType];
    MeshAlgParam meshParam(rankList.size(), myRankIdx, tempAlgParams.count, dataTypeSize);

    // 2. 判断传输模式
    bool isDmaRead = IsPcieProtocol(templateResource.channels);

    // 3. 生成数据切片
    std::vector<SliceOffset> dataSlices = GenMeshOneShotSlices(meshParam);

    // 4. 构造传输上下文
    TransferContext ctx(templateResource.threads, templateResource.channels, rankList,
                        tempAlgParams.buffInfo, param.DataDes.dataType, param.reduceType,
                        isDmaRead, tempAlgParams.buffInfo.hcclBuffBaseOff);

    // 5. 生成 OneShot AllReduce 步骤并执行
    SliceInfoList steps = GenMeshOneShotAllReduceSteps(meshParam, dataSlices, isDmaRead);
    CHK_RET(UnifiedDataTransfer(steps, ctx));

    return HCCL_SUCCESS;
}

// ===== Mesh TwoShot AllReduce 示例 =====
// 等价于原 InsTempAllReduceMesh1DTwoShot::KernelRun() 的核心逻辑
HcclResult RunMeshTwoShotAllReduceExample(const OpParam& param,
                                          const TemplateDataParams& tempAlgParams,
                                          TemplateResource& templateResource,
                                          const std::vector<u32>& rankList)
{
    // 1. 准备算法参数
    u32 myRankIdx = 0;
    CHK_RET(GetAlgRank(param.myRank, rankList, myRankIdx));
    u64 dataTypeSize = DATATYPE_SIZE_TABLE[param.DataDes.dataType];
    MeshAlgParam meshParam(rankList.size(), myRankIdx, tempAlgParams.count, dataTypeSize);

    // 2. 判断传输模式
    bool isDmaRead = IsPcieProtocol(templateResource.channels);

    // 3. 生成数据切片
    std::vector<SliceOffset> dataSlices = GenMeshTwoShotSlices(meshParam);

    // 4. 构造传输上下文
    TransferContext ctx(templateResource.threads, templateResource.channels, rankList,
                        tempAlgParams.buffInfo, param.DataDes.dataType, param.reduceType,
                        isDmaRead, tempAlgParams.buffInfo.hcclBuffBaseOff);

    // 5. ReduceScatter 阶段
    //    5a. Scatter：各 rank 并行收发数据
    SliceInfoList scatterSteps = GenMeshTwoShotScatterSteps(meshParam, dataSlices);
    CHK_RET(UnifiedDataTransfer(scatterSteps, ctx));

    //    5b. LocalReduce：本地归约
    SliceInfoList reduceSteps = GenMeshTwoShotLocalReduceSteps(meshParam, dataSlices);
    CHK_RET(UnifiedDataTransfer(reduceSteps, ctx));

    // 6. AllGather 阶段
    SliceInfoList gatherSteps = GenMeshTwoShotGatherSteps(meshParam, dataSlices);
    CHK_RET(UnifiedDataTransfer(gatherSteps, ctx));

    return HCCL_SUCCESS;
}

// ===== NHR AllGather（独立算子）示例 =====
// 等价于原 InsTempAllGatherNHR::RunAllGatherNHR() 的核心逻辑
HcclResult RunNhrAllGatherExample(const OpParam& param,
                                  const TemplateDataParams& tempAlgParams,
                                  TemplateResource& templateResource,
                                  const std::vector<u32>& rankList)
{
    u32 myRankIdx = 0;
    CHK_RET(GetAlgRank(param.myRank, rankList, myRankIdx));

    bool isDmaRead = IsPcieProtocol(templateResource.channels);

    // 生成 AllGather 步骤（支持尾块和 repeat 模式）
    SliceInfoList steps = GenNhrAllGatherOnlySteps(
        rankList.size(), myRankIdx, tempAlgParams.sliceSize, tempAlgParams.tailSize,
        tempAlgParams.repeatNum, isDmaRead);

    TransferContext ctx(templateResource.threads, templateResource.channels, rankList,
                        tempAlgParams.buffInfo, param.DataDes.dataType, param.reduceType,
                        isDmaRead, tempAlgParams.buffInfo.hcclBuffBaseOff);

    CHK_RET(UnifiedDataTransfer(steps, ctx));
    return HCCL_SUCCESS;
}

}  // namespace ops_hccl
