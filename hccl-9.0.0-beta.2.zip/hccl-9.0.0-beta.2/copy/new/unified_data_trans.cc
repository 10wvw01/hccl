/**
 * Copyright (c) 2025 Huawei Technologies Co., Ltd.
 * 函数式 UnifiedDataTransfer 数据传输机制 - 核心实现
 * 职责：基于 SliceInfoList 完成实际的数据传输操作
 * 设计原则：纯函数、无副作用、数据驱动分发
 */

#include "unified_data_trans.h"

namespace ops_hccl {

// ===== 辅助函数实现 =====

u32 GetRankFromList(const std::vector<u32>& rankList, u32 algRankIdx)
{
    if (algRankIdx >= rankList.size()) {
        HCCL_ERROR("[UnifiedDataTransfer] algRankIdx[%u] out of range[%zu]", algRankIdx, rankList.size());
        return INVALID_U32;
    }
    return rankList.at(algRankIdx);
}

DataSlice MakeDataSlice(void* baseAddr, const SliceOffset& slice, u64 extraOffset)
{
    return DataSlice(baseAddr, slice.offset + extraOffset, slice.size, slice.count);
}

// ===== 内部分发函数（纯函数，无状态）=====

// 执行本地拷贝操作
static HcclResult ExecLocalCopy(const TransferStep& step, const TransferContext& ctx)
{
    const ThreadHandle& thread = ctx.threads.at(step.threadIdx);
    DataSlice srcSlice = MakeDataSlice(ctx.buffInfo.inputPtr, step.localSrc, ctx.buffInfo.inBuffBaseOff);
    DataSlice dstSlice = MakeDataSlice(ctx.buffInfo.hcclBuff.addr, step.localDst, ctx.hcclBuffBaseOff);
    return LocalCopy(thread, srcSlice, dstSlice);
}

// 执行本地归约操作
static HcclResult ExecLocalReduce(const TransferStep& step, const TransferContext& ctx)
{
    const ThreadHandle& thread = ctx.threads.at(step.threadIdx);
    DataSlice srcSlice = MakeDataSlice(ctx.buffInfo.hcclBuff.addr, step.localSrc, ctx.hcclBuffBaseOff);
    DataSlice dstSlice = MakeDataSlice(ctx.buffInfo.hcclBuff.addr, step.localDst, ctx.hcclBuffBaseOff);
    return LocalReduce(thread, srcSlice, dstSlice, ctx.dataType, ctx.reduceOp);
}

// 构造双向收发的 SlicesList
static TxRxSlicesList BuildTxRxSlicesList(const TransferStep& step, const TransferContext& ctx,
                                          void* localBuffPtr, void* sendRemotePtr, void* recvRemotePtr)
{
    std::vector<DataSlice> txSrcSlices;
    std::vector<DataSlice> txDstSlices;
    std::vector<DataSlice> rxSrcSlices;
    std::vector<DataSlice> rxDstSlices;

    txSrcSlices.reserve(step.txSlices.size());
    txDstSlices.reserve(step.txSlices.size());
    rxSrcSlices.reserve(step.rxSlices.size());
    rxDstSlices.reserve(step.rxSlices.size());

    for (const auto& txSlice : step.txSlices) {
        txSrcSlices.emplace_back(MakeDataSlice(localBuffPtr, txSlice, ctx.hcclBuffBaseOff));
        txDstSlices.emplace_back(MakeDataSlice(sendRemotePtr, txSlice, ctx.hcclBuffBaseOff));
    }
    for (const auto& rxSlice : step.rxSlices) {
        rxSrcSlices.emplace_back(MakeDataSlice(recvRemotePtr, rxSlice, ctx.hcclBuffBaseOff));
        rxDstSlices.emplace_back(MakeDataSlice(localBuffPtr, rxSlice, ctx.hcclBuffBaseOff));
    }
    return TxRxSlicesList(SlicesList(txSrcSlices, txDstSlices), SlicesList(rxSrcSlices, rxDstSlices));
}

// 执行双向写操作（SendRecvWrite / SendRecvWriteReduce）
static HcclResult ExecSendRecvWrite(const TransferStep& step, const TransferContext& ctx, bool isReduce)
{
    u32 toUserRank = GetRankFromList(ctx.rankList, step.dstRank);
    u32 fromUserRank = GetRankFromList(ctx.rankList, step.srcRank);
    if (toUserRank == INVALID_U32 || fromUserRank == INVALID_U32) {
        return HcclResult::HCCL_E_INTERNAL;
    }

    const ChannelInfo& sendChannel = ctx.channels.at(toUserRank).at(0);
    const ChannelInfo& recvChannel = ctx.channels.at(fromUserRank).at(0);
    const ThreadHandle& thread = ctx.threads.at(step.threadIdx);

    void* localBuffPtr = ctx.buffInfo.hcclBuff.addr;
    void* sendRemotePtr = sendChannel.remoteCclMem.addr;
    void* recvRemotePtr = recvChannel.remoteCclMem.addr;

    TxRxSlicesList slicesList = BuildTxRxSlicesList(step, ctx, localBuffPtr, sendRemotePtr, recvRemotePtr);
    TxRxChannels channels(sendChannel, recvChannel);

    if (isReduce) {
        SendRecvReduceInfo info(channels, slicesList, ctx.dataType, ctx.reduceOp);
        return SendRecvWriteReduce(info, thread);
    } else {
        SendRecvInfo info(channels, slicesList);
        return SendRecvWrite(info, thread);
    }
}

// 执行双向读操作（SendRecvRead / SendRecvReadReduce）
static HcclResult ExecSendRecvRead(const TransferStep& step, const TransferContext& ctx, bool isReduce)
{
    u32 toUserRank = GetRankFromList(ctx.rankList, step.dstRank);
    u32 fromUserRank = GetRankFromList(ctx.rankList, step.srcRank);
    if (toUserRank == INVALID_U32 || fromUserRank == INVALID_U32) {
        return HcclResult::HCCL_E_INTERNAL;
    }

    const ChannelInfo& sendChannel = ctx.channels.at(toUserRank).at(0);
    const ChannelInfo& recvChannel = ctx.channels.at(fromUserRank).at(0);
    const ThreadHandle& thread = ctx.threads.at(step.threadIdx);

    void* localBuffPtr = ctx.buffInfo.hcclBuff.addr;
    void* sendRemotePtr = sendChannel.remoteCclMem.addr;
    void* recvRemotePtr = recvChannel.remoteCclMem.addr;

    TxRxSlicesList slicesList = BuildTxRxSlicesList(step, ctx, localBuffPtr, sendRemotePtr, recvRemotePtr);
    TxRxChannels channels(sendChannel, recvChannel);

    if (isReduce) {
        SendRecvReduceInfo info(channels, slicesList, ctx.dataType, ctx.reduceOp);
        return SendRecvReadReduce(info, thread);
    } else {
        SendRecvInfo info(channels, slicesList);
        return SendRecvRead(info, thread);
    }
}

// 执行单向写操作（SendWrite / RecvWrite）
static HcclResult ExecUnidirectionalWrite(const TransferStep& step, const TransferContext& ctx)
{
    const ThreadHandle& thread = ctx.threads.at(step.threadIdx);
    void* localBuffPtr = ctx.buffInfo.hcclBuff.addr;

    if (step.op == TransOp::SEND_WRITE) {
        // 发送方：本地 -> 远端
        u32 toUserRank = GetRankFromList(ctx.rankList, step.dstRank);
        if (toUserRank == INVALID_U32) {
            return HcclResult::HCCL_E_INTERNAL;
        }
        const ChannelInfo& channel = ctx.channels.at(toUserRank).at(0);
        void* remotePtr = channel.remoteCclMem.addr;

        std::vector<DataSlice> srcSlices;
        std::vector<DataSlice> dstSlices;
        for (const auto& txSlice : step.txSlices) {
            srcSlices.emplace_back(MakeDataSlice(localBuffPtr, txSlice, ctx.hcclBuffBaseOff));
            dstSlices.emplace_back(MakeDataSlice(remotePtr, txSlice, ctx.hcclBuffBaseOff));
        }
        DataInfo info(channel, SlicesList(srcSlices, dstSlices));
        return SendWrite(info, thread);
    } else {
        // 接收方：远端 -> 本地
        u32 fromUserRank = GetRankFromList(ctx.rankList, step.srcRank);
        if (fromUserRank == INVALID_U32) {
            return HcclResult::HCCL_E_INTERNAL;
        }
        const ChannelInfo& channel = ctx.channels.at(fromUserRank).at(0);
        void* remotePtr = channel.remoteCclMem.addr;

        std::vector<DataSlice> srcSlices;
        std::vector<DataSlice> dstSlices;
        for (const auto& rxSlice : step.rxSlices) {
            srcSlices.emplace_back(MakeDataSlice(remotePtr, rxSlice, ctx.hcclBuffBaseOff));
            dstSlices.emplace_back(MakeDataSlice(localBuffPtr, rxSlice, ctx.hcclBuffBaseOff));
        }
        DataInfo info(channel, SlicesList(srcSlices, dstSlices));
        return RecvWrite(info, thread);
    }
}

// 执行单向读操作（SendRead / RecvRead）
static HcclResult ExecUnidirectionalRead(const TransferStep& step, const TransferContext& ctx)
{
    const ThreadHandle& thread = ctx.threads.at(step.threadIdx);
    void* localBuffPtr = ctx.buffInfo.hcclBuff.addr;

    if (step.op == TransOp::SEND_READ) {
        // 发送方：仅 notify 同步
        u32 toUserRank = GetRankFromList(ctx.rankList, step.dstRank);
        if (toUserRank == INVALID_U32) {
            return HcclResult::HCCL_E_INTERNAL;
        }
        const ChannelInfo& channel = ctx.channels.at(toUserRank).at(0);
        std::vector<DataSlice> srcSlices;
        std::vector<DataSlice> dstSlices;
        for (const auto& txSlice : step.txSlices) {
            srcSlices.emplace_back(MakeDataSlice(localBuffPtr, txSlice, ctx.hcclBuffBaseOff));
            dstSlices.emplace_back(MakeDataSlice(channel.remoteCclMem.addr, txSlice, ctx.hcclBuffBaseOff));
        }
        DataInfo info(channel, SlicesList(srcSlices, dstSlices));
        return SendRead(info, thread);
    } else {
        // 接收方：远端 -> 本地（实际读取）
        u32 fromUserRank = GetRankFromList(ctx.rankList, step.srcRank);
        if (fromUserRank == INVALID_U32) {
            return HcclResult::HCCL_E_INTERNAL;
        }
        const ChannelInfo& channel = ctx.channels.at(fromUserRank).at(0);
        void* remotePtr = channel.remoteCclMem.addr;

        std::vector<DataSlice> srcSlices;
        std::vector<DataSlice> dstSlices;
        for (const auto& rxSlice : step.rxSlices) {
            srcSlices.emplace_back(MakeDataSlice(remotePtr, rxSlice, ctx.hcclBuffBaseOff));
            dstSlices.emplace_back(MakeDataSlice(localBuffPtr, rxSlice, ctx.hcclBuffBaseOff));
        }
        DataInfo info(channel, SlicesList(srcSlices, dstSlices));
        return RecvRead(info, thread);
    }
}

// ===== UnifiedDataTransfer 主入口 =====

HcclResult UnifiedDataTransfer(const SliceInfoList& steps, const TransferContext& ctx)
{
    for (u32 stepIdx = 0; stepIdx < steps.size(); ++stepIdx) {
        const TransferStep& step = steps[stepIdx];
        HcclResult ret = HCCL_SUCCESS;

        // 跳过空步骤（tx 和 rx 都为空且非本地操作）
        if (!IsLocalOp(step.op) && step.txSlices.empty() && step.rxSlices.empty()) {
            continue;
        }

        switch (step.op) {
            case TransOp::LOCAL_COPY:
                ret = ExecLocalCopy(step, ctx);
                break;
            case TransOp::LOCAL_REDUCE:
                ret = ExecLocalReduce(step, ctx);
                break;
            case TransOp::SENDRECV_WRITE:
                ret = ExecSendRecvWrite(step, ctx, false);
                break;
            case TransOp::SENDRECV_WRITE_REDUCE:
                ret = ExecSendRecvWrite(step, ctx, true);
                break;
            case TransOp::SENDRECV_READ:
                ret = ExecSendRecvRead(step, ctx, false);
                break;
            case TransOp::SENDRECV_READ_REDUCE:
                ret = ExecSendRecvRead(step, ctx, true);
                break;
            case TransOp::SEND_WRITE:
            case TransOp::RECV_WRITE:
                ret = ExecUnidirectionalWrite(step, ctx);
                break;
            case TransOp::SEND_READ:
            case TransOp::RECV_READ:
                ret = ExecUnidirectionalRead(step, ctx);
                break;
            default:
                HCCL_ERROR("[UnifiedDataTransfer] unknown TransOp[%d] at step[%u]", static_cast<int>(step.op), stepIdx);
                return HcclResult::HCCL_E_INTERNAL;
        }

        if (ret != HCCL_SUCCESS) {
            HCCL_ERROR("[UnifiedDataTransfer] step[%u] failed, op[%d], srcRank[%u], dstRank[%u]",
                       stepIdx, static_cast<int>(step.op), step.srcRank, step.dstRank);
            return ret;
        }
    }
    return HCCL_SUCCESS;
}

}  // namespace ops_hccl
