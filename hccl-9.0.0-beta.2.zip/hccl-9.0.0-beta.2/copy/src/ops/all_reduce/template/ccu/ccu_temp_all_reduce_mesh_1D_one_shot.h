/**
 * Copyright (c) 2025 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */


#ifndef HCCL_CCU_TEMP_ALL_REDUCE_MESH_1D_ONE_SHOT_H_
#define HCCL_CCU_TEMP_ALL_REDUCE_MESH_1D_ONE_SHOT_H_

#include <ios>
#include "ccu_alg_template_base.h"
#include "utils.h"

namespace ops_hccl {

class CcuTempAllReduceMesh1DOneShot : public CcuAlgTemplateBase {
public:
    CcuTempAllReduceMesh1DOneShot() = default;
    explicit CcuTempAllReduceMesh1DOneShot(const OpParam& param, 
                                           const u32 rankId, // 传通信域的rankId，userRank
                                           const std::vector<std::vector<u32>> &subCommRanks);
    ~CcuTempAllReduceMesh1DOneShot() override;

    HcclResult CalcRes(HcclComm comm, const OpParam& param, const TopoInfoWithNetLayerDetails* topoInfo,
                    AlgResourceRequest& resourceRequest) override;

    HcclResult KernelRun(const OpParam& param,
                        const TemplateDataParams& templateDataParams,
                        TemplateResource& templateResource) override;
    HcclResult FastLaunch(const OpParam& param, const TemplateFastLaunchCtx& tempFastLaunchCtx) override;
    
    std::string Describe() const override
    {
        return StringFormat("Template of CcuTempAllReduceMesh1DOneShot subCommRanks_[0].size() [%u].", subCommRanks_[0].size());
    }

    u64 CalcScratchMultiple(BufferType inBuffType, BufferType outBuffType) override;
private:
    uint32_t mySubCommRank_ = 0;
};

} // namespace Hccl

#endif // HCCLV2_CCU_TEMP_ALL_REDUCE_MESH_1D_H_