/**
 * Copyright (c) 2025 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

#ifndef HCCLV2_ALLREDUCE_AUTO_SELECTOR
#define HCCLV2_ALLREDUCE_AUTO_SELECTOR

#include "auto_selector_base.h"

namespace ops_hccl {

class AllReduceAutoSelector : public AutoSelectorBase {
private:
    SelectorStatus SelectCcuMsAlgo(const TopoInfoWithNetLayerDetails* topoInfo, const OpParam &opParam,
                                 const std::map<HcclCMDType, std::vector<HcclAlgoType>> &configAlgMap,
                                 std::string                                 &selectAlgName) const override;
    SelectorStatus SelectCcuScheduleAlgo(const TopoInfoWithNetLayerDetails* topoInfo, const OpParam &opParam,
                                 const std::map<HcclCMDType, std::vector<HcclAlgoType>> &configAlgMap,
                                 std::string &selectAlgName) const override;
    SelectorStatus SelectCcuScheduleLevel0Algo(const TopoInfoWithNetLayerDetails* topoInfo, const OpParam &opParam,
                                 std::string &selectAlgName, const u64 dataSize) const;
    SelectorStatus SelectCcuScheduleLevel0UBXAlgo(const TopoInfoWithNetLayerDetails* topoInfo, 
        std::string &selectAlgName, const u64 dataSize) const;
    SelectorStatus SelectAicpuAlgo(const TopoInfoWithNetLayerDetails* topoInfo, const OpParam &opParam,
                                   const std::map<HcclCMDType, std::vector<HcclAlgoType>> &configAlgMap,
                                   std::string &selectAlgName) const override;
    SelectorStatus SelectMeshAlgo(const TopoInfoWithNetLayerDetails* topoInfo, const OpParam &opParam,
                                  std::string &selectAlgName) const;
    SelectorStatus SelectAivAlgo(const TopoInfoWithNetLayerDetails* topoInfo, const OpParam &opParam,
                                 const std::map<HcclCMDType, std::vector<HcclAlgoType>> &configAlgMap,
                                 std::string &selectAlgName) const override;
    SelectorStatus SelectMeshAlgoAicpu(const TopoInfoWithNetLayerDetails* topoInfo, const OpParam &opParam,
                                       std::string &selectAlgName) const;
    SelectorStatus SelectDPUAlgo(const TopoInfoWithNetLayerDetails* topoInfo, const OpParam &opParam,
        const std::map<HcclCMDType, std::vector<HcclAlgoType>> &configAlgMap, std::string &selectAlgName) const;
    SelectorStatus SelectMeshAlgoAicpuUBX(const TopoInfoWithNetLayerDetails* topoInfo, const u64 dataSize, 
        std::string &selectAlgName) const;
    SelectorStatus SelectMeshUBXAlgo(const TopoInfoWithNetLayerDetails* topoInfo, std::string &selectAlgName, 
        u64 dataSize) const;
};

} // namespace ops_hccl
#endif