# 点对点通信 - HcclBatchSendRecv（实现 Ring）

## 样例介绍

本样例展示如何使用 `HcclBatchSendRecv()` 接口实现环状的点对点通信，包含以下功能点：

- 设备检测，通过 `aclrtGetDeviceCount()` 接口查询可用设备数量。
- 将 rank0 作为 root 节点，通过 `HcclGetRootInfo()` 接口生成 root 节点的 rootinfo 标识信息。

  > rootinfo 标识信息主要包含：Device IP、Device ID 等信息，此信息需广播至集群内所有 rank 用来初始化通信域。

- 在每个线程中，基于 rootinfo 标识信息通过 `HcclCommInitRootInfo()` 接口初始化通信域。
- 调用 `HcclBatchSendRecv()` 接口，将数据发送至下一节点，同时接收上一节点的数据，最后打印结果。

## 目录结构

```text
├── main.cc                 # 样例源文件
├── Makefile                # 编译/构建配置文件
└── batch_send_recv_ring    # 编译生成的可执行文件
```

## 环境准备

### 环境要求

本样例支持以下产品：

- <term>Ascend 950PR</term> / <term>Ascend 950DT</term>
- <term>Atlas A3 训练系列产品</term> / <term>Atlas A3 推理系列产品</term>
- <term>Atlas A2 训练系列产品</term>
- <term>Atlas 训练系列产品</term>

### 配置环境变量

```bash
# 设置 CANN 环境变量，以 root 用户默认安装路径为例
source /usr/local/Ascend/cann/set_env.sh
```

## 编译执行样例

在本样例代码目录下执行如下命令：

```bash
make
make test
```

> 注意：可通过设置 `HCCL_OP_EXPANSION_MODE` 环境变量配置通信算法的任务编排展开位置，不同产品型号支持的范围可参考[环境变量列表](https://hiascend.com/document/redirect/CannCommunityEnvRef)中该环境变量的使用方法。
>
> ```bash
> # 设置通信算法的编排展开位置在Device侧的AI CPU，Device侧根据硬件型号自动选择相应的调度器
> export HCCL_OP_EXPANSION_MODE=AI_CPU
> ```

## 结果示例

每个节点的 `sendBuf` 内容初始化为 Device Id，将数据发送至下一节点，同时接收上一节点的数据，因此各个节点接收到的是上一节点的 Device Id。

```text
Found 8 NPU device(s) available
rankId: 0, output: [ 7 7 7 7 7 7 7 7 ]
rankId: 1, output: [ 0 0 0 0 0 0 0 0 ]
rankId: 2, output: [ 1 1 1 1 1 1 1 1 ]
rankId: 3, output: [ 2 2 2 2 2 2 2 2 ]
rankId: 4, output: [ 3 3 3 3 3 3 3 3 ]
rankId: 5, output: [ 4 4 4 4 4 4 4 4 ]
rankId: 6, output: [ 5 5 5 5 5 5 5 5 ]
rankId: 7, output: [ 6 6 6 6 6 6 6 6 ]
```
