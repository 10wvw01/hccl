# HCCL 公共函数优化方案分析文档（v2）

## 概述

本文档详细分析了三项优化任务的可行性、实施方案及技术细节：
1. 将 `PreSyncIfMultiThread` / `PostSyncIfMultiThread` 合并到 `PreCopy` / `PostCopy` 流程
2. 对 `PreCopyToScratch` / `PostCopyFromScratch` 进行命名优化
3. 将 `AicpuReduceBarrier` 合并到 `LocalDmaReduceCopy` 流程

---

## Task 1: 合并 PreSync/PostSync 到 PreCopy/PostCopy 流程

### 1.1 可行性分析

| 维度 | 评估 | 详细说明 |
|------|------|---------|
| **功能完整性** | ✅ 可行 | sync 和 copy 虽是独立功能，但在实际调用中总是成对出现（PreSync→ScatterData→PostSync）。合并后通过重载实现，不破坏原有功能 |
| **代码耦合度** | ✅ 低耦合 | 通过 C++ 函数重载（而非修改原函数签名）实现。无 sync 参数时退化为纯 copy，有 sync 参数时自动组合 |
| **性能影响** | ✅ 零影响 | 仅是函数调用的组合，编译器可完全内联展开，无额外运行时开销 |
| **向后兼容** | ✅ 完全兼容 | 保留无 sync 的原版本，新增带 sync 的重载版本。已有调用方无需修改 |

### 1.2 合并方案

**策略**：函数重载（非侵入式合并）

```cpp
// 原版本（保留，向后兼容）
HcclResult PreCopyToBuffer(thread, buffInfo, myAlgRank, sliceSize, sliceCount);

// 新增带 sync 重载版本
HcclResult PreCopyToBuffer(thread, buffInfo, myAlgRank, sliceSize, sliceCount,
                           mainThread, subThreads, notifyIdxMainToSub);
```

**执行顺序**：
- `PreCopyToBuffer`（带 sync）：`PreSyncIfMultiThread` → `PreCopyToBuffer`（纯拷贝）
- `PostCopyToOutput`（带 sync）：`PostCopyToOutput`（纯拷贝）→ `PostSyncIfMultiThread`

### 1.3 实施步骤

1. 在 [alg_data_trans_wrapper.h](src/ops/op_common/template/wrapper/alg_data_trans_wrapper.h) 中新增两个重载声明
2. 在 [alg_data_trans_wrapper.cc](src/ops/op_common/template/wrapper/alg_data_trans_wrapper.cc) 中实现重载版本（内部调用原版本 + sync）
3. 调用方逐步迁移到带 sync 版本（可选，不强制）
4. 保留独立 `PreSyncIfMultiThread` / `PostSyncIfMultiThread` 供非 copy 场景使用

### 1.4 合并前后对比

**合并前**（调用方需写 4-5 行）：
```cpp
if (threads.size() > 1) {
    std::vector<ThreadHandle> subThreads(threads.begin() + 1, threads.end());
    GetNotifyIdxMainToSub(notifyIdxMainToSub_);
    CHK_RET(PreSyncInterThreads(threads[0], subThreads, notifyIdxMainToSub_));
}
CHK_RET(PreCopyToBuffer(threads[0], buffInfo, myAlgRank, sliceSize, sliceCount));
```

**合并后**（调用方只需 1 行）：
```cpp
CHK_RET(PreCopyToBuffer(threads[0], buffInfo, myAlgRank, sliceSize, sliceCount,
                        threads[0], subThreads, notifyIdxMainToSub_));
```

---

## Task 2: 命名优化（移除 Scratch 限定）

### 2.1 命名变更理由

| 原命名 | 新命名 | 变更理由 |
|--------|--------|---------|
| `PreCopyToScratch` | `PreCopyToBuffer` | 目标 buffer 不一定是 "scratch"，也可能是 hcclBuff、cclBuff 等。移除 "Scratch" 使命名更具通用性和扩展性 |
| `PostCopyFromScratch` | `PostCopyToOutput` | 源 buffer 不一定是 "scratch"，关键是目标是 output。"ToOutput" 比 "FromScratch" 更准确地反映实际功能（数据流向 output） |

### 2.2 命名规范分析

**原命名问题**：
- `PreCopyToScratch`：限定目标为 "Scratch"，但实际目标可能是任何中间 buffer
- `PostCopyFromScratch`：限定源为 "Scratch"，但实际源可能是任何中间 buffer；且命名只描述了"从哪里来"而非"到哪里去"，不够直观

**新命名优势**：
- `PreCopyToBuffer`：清晰表达"拷贝到 buffer"（中间 buffer），与 `PostCopyToOutput`（拷贝到 output）形成对称
- `PostCopyToOutput`：清晰表达"拷贝到 output"（最终输出），与 `PreCopyToBuffer` 形成对称
- 两者都以**目标**命名，符合"动词+目标"的命名惯例

### 2.3 实施步骤

1. 在 `.h` / `.cc` 中将 `PreCopyToScratch` 全局替换为 `PreCopyToBuffer`
2. 在 `.h` / `.cc` 中将 `PostCopyFromScratch` 全局替换为 `PostCopyToOutput`
3. 更新所有调用方文件中的函数名引用
4. 更新错误日志中的函数名（如 `HCCL_ERROR("[AlgDataTransWrapper] PreCopyToBuffer: ...")`）

---

## Task 3: 合并 AicpuReduceBarrier 到 LocalDmaReduceCopy

### 3.1 功能关联性分析

| 函数 | 功能 | 输入资源 | 输出效果 |
|------|------|---------|---------|
| `LocalDmaReduceCopy` | input→output DMA 数据拷贝 | 单个 thread + buffInfo | 数据从 input 搬运到 output |
| `AicpuReduceBarrier` | 线程同步（BatchModeEnd/Start/Join） | algTag + 所有 threads | 确保所有线程任务完成 |

**关联性**：在 reduce 流程中，DMA 拷贝完成后需要 barrier 确保所有线程数据就绪，才能开始软件归约（AicpuReduce）。两者存在**顺序依赖**：先拷贝数据，再同步等待。

### 3.2 执行顺序分析

**场景 A：DMA Copy 与 Barrier 相邻**（可合并）
```
LocalDmaReduceCopy → AicpuReduceBarrier → ReduceData
```
此场景下 barrier 紧跟 DMA copy，合并后调用方只需一次调用。

**场景 B：DMA Copy 与 Barrier 不相邻**（不可合并）
```
LocalDmaReduceCopy → GatherData → PostSync → AicpuReduceBarrier → ReduceData
```
此场景下 barrier 前有其他操作（GatherData、PostSync），不能直接合并。

### 3.3 合并策略

**策略**：函数重载 + 可选 barrier 标志

```cpp
// 原版本（保留，向后兼容）
HcclResult LocalDmaReduceCopy(thread, buffInfo, processSize, count);

// 合并版本：DMA 拷贝 + 可选 barrier
HcclResult LocalDmaReduceCopy(thread, buffInfo, processSize, count,
                              algTag, allThreads, needBarrier, barrierTimeout = 0);
```

**执行顺序**：`LocalDmaReduceCopy`（数据拷贝）→ `AicpuReduceBarrier`（线程同步，仅当 needBarrier=true）

### 3.4 资源依赖分析

| 资源 | LocalDmaReduceCopy | AicpuReduceBarrier | 合并后 |
|------|-------------------|-------------------|--------|
| thread | ✅ 单个线程 | ✅ 所有线程 | ✅ 单个线程（copy）+ 所有线程（barrier） |
| buffInfo | ✅ 需要 | ❌ 不需要 | ✅ 需要 |
| algTag | ❌ 不需要 | ✅ 需要 | ✅ 需要（仅 barrier 时） |
| timeout | ❌ 不需要 | ✅ 可选 | ✅ 可选（仅 barrier 时） |

### 3.5 实施步骤

1. 在 `.h` 中新增 `LocalDmaReduceCopy` 的带 barrier 重载声明
2. 在 `.cc` 中实现重载版本（内部先调用原版本做拷贝，再按需调用 `AicpuReduceBarrier`）
3. 保留独立 `AicpuReduceBarrier` 供非 DMA 场景使用（如 [reduce_mesh_1D.cc](src/ops/reduce/template/aicpu/reduce_mesh_1D.cc) 中 barrier 在 PostSync 之后的情况）
4. 调用方按场景选择：
   - DMA Copy 与 Barrier 相邻 → 使用合并版本
   - DMA Copy 与 Barrier 不相邻 → 使用独立版本

### 3.6 合并前后对比

**合并前**（场景 A，需 2 次调用）：
```cpp
CHK_RET(LocalDmaReduceCopy(threads[0], buffInfo, processSize, count));
if (needAicpuReduce_) {
    CHK_RET(AicpuReduceBarrier(param.algTag, threads));
}
```

**合并后**（场景 A，只需 1 次调用）：
```cpp
CHK_RET(LocalDmaReduceCopy(threads[0], buffInfo, processSize, count,
                           param.algTag, threads, needAicpuReduce_));
```

**场景 B**（DMA Copy 与 Barrier 不相邻，仍使用独立版本）：
```cpp
// GatherData 内部调用 LocalDmaReduceCopy（无 barrier）
CHK_RET(GatherData(tempAlgParam, channels, threads));
// PostSync
CHK_RET(PostSyncIfMultiThread(masterThread, subThreads, notifyIdxSubToMain_));
// 独立 barrier（在 PostSync 之后，不与 DMA Copy 相邻）
if (needAicpuReduce_) {
    CHK_RET(AicpuReduceBarrier(param.algTag, threads));
}
```

---

## 综合评估

### 优化效果汇总

| 优化项 | 消除的重复 | 新增 API | 向后兼容 | 性能影响 |
|--------|-----------|---------|---------|---------|
| Task 1: sync 合并 | 调用方 4-5 行 sync 代码 → 1 行 | +2 个重载 | ✅ 保留原版本 | 零影响 |
| Task 2: 命名优化 | 消除 Scratch 误导性限定 | 0（纯重命名） | ⚠️ 需更新调用方 | 零影响 |
| Task 3: barrier 合并 | 场景 A 下 2 次调用 → 1 次 | +1 个重载 | ✅ 保留原版本 | 零影响 |

### API 变更总览

| 变更类型 | 函数 | 说明 |
|---------|------|------|
| **重命名** | `PreCopyToScratch` → `PreCopyToBuffer` | 移除 Scratch 限定 |
| **重命名** | `PostCopyFromScratch` → `PostCopyToOutput` | 移除 Scratch 限定 |
| **新增重载** | `PreCopyToBuffer` (+sync) | 合并 PreSync 到 PreCopy |
| **新增重载** | `PostCopyToOutput` (+sync) | 合并 PostSync 到 PostCopy |
| **新增重载** | `LocalDmaReduceCopy` (+barrier) | 合并 AicpuReduceBarrier 到 DMA Copy |
| **保留** | `PreSyncIfMultiThread` / `PostSyncIfMultiThread` | 供非 copy 场景使用 |
| **保留** | `AicpuReduceBarrier` | 供非 DMA 场景使用 |

### 风险评估

| 风险 | 等级 | 缓解措施 |
|------|------|---------|
| 重命名导致编译错误 | 低 | 通过全局替换确保一致性；C++ 编译器会在编译期捕获遗漏 |
| 重载歧义 | 低 | 参数数量不同，C++ 重载决议无歧义 |
| barrier 合并后遗漏独立 barrier | 低 | 保留独立版本，调用方按场景选择 |
| 性能回退 | 无 | 所有新增函数都是原函数的组合，编译器可完全内联 |
